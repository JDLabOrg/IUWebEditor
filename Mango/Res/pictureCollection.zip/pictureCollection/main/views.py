from django.shortcuts import render_to_response
from django.template import RequestContext
from main.models import Picture

def index(request):
    errors = []
    if request.method == 'POST':
        if not request.POST.get('url', ''):
            errors.append('Enter an URL')
        if not request.POST.get('title', ''):
            errors.append('Enter a title')
        if not request.POST.get('link', ''):
            errors.append('Enter a link')
        if not request.POST.get('desc', ''):
            errors.append('Enter a desc')
        if not errors:
            picture = Picture(url=request.POST.get('url'),
                    title=request.POST.get('title'),
                    link=request.POST.get('link'),
                    desc = request.POST.get('desc'))
            picture.save()

    print errors
    pictures = Picture.objects.all()[2:]
    print pictures
    return render_to_response('index.html', {'firstCol':pictures, }, context_instance = RequestContext(request))
