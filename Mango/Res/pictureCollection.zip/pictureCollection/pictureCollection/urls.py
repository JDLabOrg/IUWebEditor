from django.conf.urls import patterns, url, include
from django.views.generic import TemplateView
from main import views

urlpatterns = patterns('',
    ('^$', views.index),
    ('^index.html$', views.index),
    # Examples:
    # url(r'^$', 'pictureCollection.views.home', name='home'),
    # url(r'^pictureCollection/', include('pictureCollection.foo.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
