document.carouselDict = {};

$.fn.carousel = function(){
	return {
	length:0,  		// 	the number of items
	current:0,		// 	current index
	width: 0,		//	carouselItemBox width -- contentbox Width
        
	prev: function(iuname){	//prev - click
		if(this.current >0){
			this.current = this.current -1;
		}else{
			this.current = this.length-1;
		}
		this.animation(iuname);
	},
	next:function(iuname){	//next - click
		if(this.current < this.length-1){
			this.current = this.current+1;
		}
		else{
			this.current = 0;
		}
		this.animation(iuname);
	},
        
	clickIndex:function(iuname, index){
		this.current = index;
		this.animation(iuname);
	},
        
	animation: function(iuname){
		var currentItems = IU(iuname).children().filter('.IUCarouselItemBox').children();
		var boxWidth = IU(iuname).iuPosition().width;
		
		var left = (-1)*this.current* boxWidth;
		var firstItem = currentItems[0];
		$(currentItems).stop().animate(
                                    {'left' : left},
                                    1000
                                    );
	},
        
        
        initialize : function(iu, iuname){
            
            //setting for click
            //Next
            $(iu).children().filter(".IUNext").click(function(){
                                                     var iuname = $(this).parent().iuName();
                                                     document.carouselDict[iuname].next(iuname);
                                                     });
            
            //Prev
            $(iu).children().filter(".IUPrev").click(function(){
                                                     var iuname = $(this).parent().iuName();
                                                     document.carouselDict[iuname].prev(iuname);
                                                     });
            
			$(iu).children().filter(".IUCarouselControlBar").children().click(function(){
                                                                   var iuname = $(this).parent().parent().iuName();
                                                                   var index = $(this).attr('c-index');
                                                                   document.carouselDict[iuname].clickIndex(iuname, index);
                                                                   })
        }
	}
}


function IUCarouselInitialize(){
	var iucarouselIUs = $('.IUCarousel').toArray();
	$.each(iucarouselIUs, function(i, iu){
           var iuname = $(iu).iuName();
           document.carouselDict[iuname] = $(iu).carousel();
           document.carouselDict[iuname].initialize(iu, iuname);
           document.carouselDict[iuname].length = parseInt($(iu).children().filter('.IUCarouselItemBox').children().length)
           document.carouselDict[iuname].width = $(iu).children().filter('.IUCarouselItemBox').iuPosition().width;
           });
}

$(document).ready(function(){
                  
                  IUCarouselInitialize();
                  
                  
                  })